// Cache ownership follows the complete registration scope, not a shared product prefix.
const PREFIX = 'lexltest01115-scope:' + encodeURIComponent(self.registration.scope) + ':';
const CACHE = PREFIX + '01115-test-'+"f2bf885de376"+'-v1';
const ASSETS = ['./', './index.html', './data-layer.js', './storage-transition.js',
  './storage-session.js', './backup-package.js', './program-1.webp', './program-2.webp',
  './program-3.webp', './manifest.webmanifest', './icon-192.png', './icon-512.png',
  './test-logo.svg', './test-bootstrap.js', './build-info.json'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => { event.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || !event.request.url.startsWith(self.registration.scope)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    if (event.request.mode === 'navigate') {
      try {
        const response = await fetch(event.request);
        if (response.ok) {
          const copy = response.clone();
          event.waitUntil(cache.put(event.request, copy).catch(() => {}));
        }
        return response;
      } catch {
        return await cache.match(event.request) || await cache.match(new URL('index.html', self.registration.scope).href) || Response.error();
      }
    }
    return await cache.match(event.request) || fetch(event.request);
  })());
});
